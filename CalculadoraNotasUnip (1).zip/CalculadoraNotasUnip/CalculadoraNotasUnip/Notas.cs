﻿namespace CalculadoraNotasUnip
{
    public class Notas
    {
        public double Nota1 { get; set; }
        public double Nota2 { get; set; }
        public double Nota3 { get; set; }
        public double Nota4 { get; set; }
        public double NotaExame { get; set; }
        public double MediaAnual { get; set; }
    }
}